import { ScrollViewStyleReset } from "expo-router/html";
import type { PropsWithChildren } from "react";

export default function Root({ children }: PropsWithChildren) {
  return (
    <html lang="es">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
        <meta name="theme-color" content="#0f172a" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="Under Pressure Camp" />
        <meta name="description" content="Control QR de campistas, pagos y comidas de Under Pressure Camp." />
        <link rel="manifest" href="/manifest.webmanifest" />
        <link rel="icon" href="/assets/images/favicon.png" />
        <link rel="apple-touch-icon" href="/assets/images/icon.png" />
        <ScrollViewStyleReset />
        <style dangerouslySetInnerHTML={{
          __html: `
            html, body, #root { width: 100%; min-height: 100%; margin: 0; padding: 0; }
            html { background: #f8fafc; overscroll-behavior-y: none; }
            body { min-height: 100vh; -webkit-font-smoothing: antialiased; text-rendering: optimizeLegibility; }
            @media (display-mode: standalone) {
              body { padding-top: env(safe-area-inset-top); padding-bottom: env(safe-area-inset-bottom); }
            }
          `,
        }} />
      </head>
      <body>{children}</body>
    </html>
  );
}
