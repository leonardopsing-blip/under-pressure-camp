# Under Pressure Camp — PWA

This project now includes a web/PWA target so it can be used on iPhone without an Apple Developer account or App Store installation.

## Run locally

```bash
npm install
npm run web
```

## Build the web/PWA version

```bash
npm run build:web
```

The static web output is generated in `dist/`.

## iPhone installation

The deployed site must use HTTPS. On iPhone, open the site in Safari and use:

**Compartir → Añadir a pantalla de inicio → Abrir como app web → Añadir**

The PWA manifest, Apple web-app metadata and service worker are already included.

## Important

The PWA keeps the existing API/backend and Google Sheets integration. API routes are intentionally excluded from service-worker caching so live data remains live.

The QR camera requires browser camera permission and HTTPS on a real iPhone.
